To build this module, get the FAAD2 library Version 2.0rc3 (see http://www.audiocoding.com/)
and add the paths to your .buildrc file: 

SetSDKPath("faad2_include", "/path/to/faad2/include")
SetSDKPath("faad2_lib", "/path/to/faad2/library")

For documentation on .buildrc files, see ribosome/build/doc/buildrc.html.
