#define INITGUID
#include "hxacodec.h"
#include "dunitprvt.h"

